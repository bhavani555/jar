package travel;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
//import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Travel
 */
@WebServlet("/Travel")
public class Travel extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con =null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try{
			 con = DatabaseConnection.initializeDatabase();
			
			
			PreparedStatement st = con.prepareStatement("insert into detail values(?, ?)");
			
			st.setString(1,  request.getParameter("username"));
			
			st.setString(2,  request.getParameter("password"));
			
			int count = st.executeUpdate();
			System.out.println("total number of rpws affected here" +count);
			
			st.close();
			con.close();
			PrintWriter out = response.getWriter();
			out.println("<html><body><b>successfully inserted" + "</b></body></html>");
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			System.out.println("excepttion");
			
		}
	}

}
